﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace Individual_project.Entity
{
    public  class User
    {
        
        public string Name;
        private string password;
        public string Password {
            get
            {
                return password;
            }
            set
            {
                password = PasswordEncoder(value);
            }
        }


        public User() {}
        public User(string name, string password) {
            this.Name = name;
           
            Password = password;
        }

        private string PasswordEncoder(string password)
        {
            if ((password == null) || (password.Length == 0))
            {
                return string.Empty;
            }
            string answ = "";
            int shift = (int)password[0] / 36;
            string a = "a";
            answ += (char)(shift + (int)(a[0]));
            foreach (char st in password)
            {
                answ += (char)((int)st + shift);
            }

            return answ;
        }
        private string PasswordDecoder(string password)
        {
            string answ = "";
            if ((password == null)||(password.Length == 0))
            {
                return string.Empty;
            }
            string a = "a";
            int shift = (int)password[0] - (int)((char)(a[0]));
            for (int i = 1; i < password.Length; i++)
            {
                answ += (char)((int)password[i] - shift);
            }
            return answ;
        }
    }
}
