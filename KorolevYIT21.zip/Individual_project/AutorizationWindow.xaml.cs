﻿using Individual_project.Dao;
using Individual_project.Entity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Individual_project
{
    /// <summary>
    /// Interaction logic for AutorizationWindow.xaml
    /// </summary>
    public partial class AutorizationWindow : Window
    {
        DatabaseConnect dbconnect = new DatabaseConnect();
        public AutorizationWindow()
        {
            InitializeComponent();
        }
        public bool IsEnterClicked = false;

        public User NewUser
        {
            get { return new User(NickName.Text, Password.Text); }
        }
        private void Autorize_Click(object sender, RoutedEventArgs e) {
            string password1, password2, nickname;
            nickname = NickName.Text;
            password1 = Password.Text;
            password2 = PasswordApprove.Text;
            if (string.Equals(password1, password2))
            {
                if (nickname.Any(c => char.IsLetter(c) || char.IsNumber(c)))
                {
                    if(password1.Any(c => char.IsLetter(c) || char.IsNumber(c)))
                    {
                        dbconnect.AddUser(new User(NickName.Text, Password.Text));
                        this.DialogResult = true;
                    }
                    else
                    {
                        MessageBox.Show("Использованы недопустимые символы в пароле");
                    }
                }
                else
                {
                    MessageBox.Show("Использованы недопустимые символы в имени");
                }
            }
            else
            {
                MessageBox.Show("Пароли не совпадают");
            }
            
        }
        private void Enter_Click(object sender, RoutedEventArgs e) {
            this.IsEnterClicked = true;
            this.DialogResult = false;
        }
    }
}
