﻿using Individual_project.Entity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace Individual_project.Dao
{

    internal class DatabaseConnect
        
    {
        
        public DatabaseConnect()
        {
            

            
        }
        public void AddUser(User user)
        {
            XDocument xdoc = XDocument.Load(@"..\..\users.xml");
            XElement root = xdoc.Element("users");
            if (root != null)
            {
                // добавляем новый элемент
                root.Add(new XElement("user",
                            new XAttribute("Name", user.Name),
                            new XElement("password", user.Password)
                            ));

                xdoc.Save(@"..\..\users.xml");
            }
        }
        public bool FindUser(User tuser)
        {
            XDocument xdoc = XDocument.Load(@"..\..\users.xml");
            XElement users = xdoc.Element("users");
            if (users != null)
            {
                foreach (XElement user in users.Elements("user"))
                {
                    if (user.Attribute("Name").Value == tuser.Name)
                    {
                        if (user.Element("password").Value == tuser.Password)
                        {
                            return true;
                        }
                    }
                }
                
            }
            return false;
        }
    }
}
