﻿using Individual_project.Warship;
using Individual_project.Entity;
using Individual_project.RubicCube;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Individual_project
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public string Stylesheet { get; set; }
        private User user;
        private string theme { get; set; } = "light";
        public MainWindow()
        {
            InitializeComponent();
            List<string> styles = new List<string> { "dark", "light" };
            Styles.ItemsSource = styles;
            Styles.SelectedItem = theme;
            Styles.SelectionChanged += ThemeChange;
            this.Stylesheet = "light";
            NickName.Visibility = Visibility.Hidden;
            Application.Current.Resources.Clear();
            var uri = new Uri(this.Stylesheet + ".xaml", UriKind.Relative);
            ResourceDictionary resourceDictionary = Application.LoadComponent(uri) as ResourceDictionary;
            Application.Current.Resources.Clear();
            Application.Current.Resources.MergedDictionaries.Add(resourceDictionary);
        }

        
        private void Autorization_Click(object sender, RoutedEventArgs e)
        {
           AutorizationWindow autorizationWindow = new AutorizationWindow();
            autorizationWindow.Owner = this;
            if (autorizationWindow.ShowDialog() == true) {
                user = autorizationWindow.NewUser as User;
                NickName.Text = user.Name;
                NickName.Visibility = Visibility.Visible;
                Enter.Visibility = Visibility.Hidden;
                Autorize.Visibility = Visibility.Hidden;
            }
            else if (autorizationWindow.IsEnterClicked)
            {
                Enter.RaiseEvent(new RoutedEventArgs(Button.ClickEvent));
            }
        }
        private void Enter_Click(object sender, RoutedEventArgs e)
        {
            EnterWindow enter_window = new EnterWindow();
            enter_window.Owner = this;
            if (enter_window.ShowDialog() == true)
            {
                user = enter_window.RegisterUser as User;
                NickName.Text = user.Name;
                NickName.Visibility = Visibility.Visible;
                Enter.Visibility = Visibility.Hidden;
                Autorize.Visibility = Visibility.Hidden; 
            }
            else if(enter_window.IsAutorizeClicked) {
                Autorize.RaiseEvent(new RoutedEventArgs(Button.ClickEvent));
            }
        }
        private void Warship_Click(object sender, RoutedEventArgs e)
        {
            if (user == null) {
                Enter.RaiseEvent(new RoutedEventArgs(Button.ClickEvent));
                return; }
            Individual_project.Warship.Battleship battleship = new Individual_project.Warship.Battleship();
            battleship.Show();
            
        }
        private void Rubic_Click(object sender, RoutedEventArgs e)
        {
            if (user == null)
            {
                Enter.RaiseEvent(new RoutedEventArgs(Button.ClickEvent));
                return;
            }
            Individual_project.RubicCube.RubicCube rubic = new Individual_project.RubicCube.RubicCube();
            rubic.Show(); 
        }
        private void ThemeChange(object sender, SelectionChangedEventArgs e)
        {
            string style = Styles.SelectedItem as string;
            var uri = new Uri(style + ".xaml", UriKind.Relative);
            ResourceDictionary resourceDict = Application.LoadComponent(uri) as ResourceDictionary;
            Application.Current.Resources.Clear();
            Application.Current.Resources.MergedDictionaries.Add(resourceDict);
        }
    }
}
