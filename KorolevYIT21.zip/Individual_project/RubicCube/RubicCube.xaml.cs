﻿using Individual_project.RubicCube.VM;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Web;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Media.Media3D;
using System.Windows.Shapes;
using System.Windows.Threading;

namespace Individual_project.RubicCube
{
    /// <summary>
    /// Interaction logic for RubicCube.xaml
    /// </summary>
    public partial class RubicCube : Window
    {
        CubeModelVM cubeModel = new CubeModelVM();
        //0,1 1,1 1,0 0,0

        private void RotateTransform3D_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.W)
            {
                cubeModel.UpKey = false;
            }
            if (e.Key == Key.S)
            {
                cubeModel.DownKey = false;
            }
            if (e.Key == Key.D)
            {
                cubeModel.RightKey = false;
            }
            if (e.Key == Key.A)
            {
                cubeModel.LeftKey = false;
            }
        }

        public RubicCube()
        {
            
            DataContext = cubeModel;
            InitializeComponent();
            GameScreen.Focus();
        }

        private void RotateTransform3D_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.W)
            {
                
                cubeModel.UpKey = true;
                
            }
            if (e.Key == Key.S)
            {
                cubeModel.DownKey = true;
            }
            if(e.Key == Key.D){
                cubeModel.RightKey = true;
            }
            if(e.Key == Key.A)
            {
                cubeModel.LeftKey = true;
            }
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            var btn = (Button)sender;
            string command = btn.Content.ToString();
            cubeModel.cubeMotion(command);
        }
        private void AssembleCube_Click(object sender, RoutedEventArgs e)
        {
            cubeModel.GenerateSides();
        }
    }

}
