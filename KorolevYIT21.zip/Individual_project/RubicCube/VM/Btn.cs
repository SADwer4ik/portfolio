﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace Individual_project.RubicCube.VM
{
    internal class Btn
    {
        public string Text { get; set; }
        public Btn(string text) { this.Text = text; }
    }
}
