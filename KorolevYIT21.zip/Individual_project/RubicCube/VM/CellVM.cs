﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace Individual_project.RubicCube.VM
{
    internal class CellVM : INotifyPropertyChanged
    {
        //public string Color { get; set; } = "#b7ff2b";
        public event PropertyChangedEventHandler PropertyChanged;
        private string color;
        public string Color {
            get { return color; }
            set {
                if (value == "blue")
                {
                    color = "#0000ff";
                }
                else if (value == "green")
                {
                    color = "#b7ff2b";
                }

                else if (value == "orange")
                {
                    color = "#fd7f06";
                }
                else if (value == "white")
                {
                    color = "#ffdab9";
                }
                else if (value == "purple")
                {
                    color = "#a5209b";
                }
                else if (value == "red")
                {
                    color = "#7F1425";
                }
                OnPropertyChanged("Color");
            }
        }
        public void PureColor(string color)
        {
            this.color = color;
            OnPropertyChanged("Color");
        }
        public void OnPropertyChanged([CallerMemberName] string prop = "")
        {
            
            if (PropertyChanged != null)
                PropertyChanged(this, new PropertyChangedEventArgs(prop));
        }
    }
}
