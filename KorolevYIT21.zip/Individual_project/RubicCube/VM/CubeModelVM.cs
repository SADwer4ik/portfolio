﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Net.Http.Headers;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Media.Animation;
using System.Windows.Media.Media3D;
using System.Windows.Threading;

using Vectors;
namespace Individual_project.RubicCube.VM
{
    internal class CubeModelVM : INotifyPropertyChanged
    {

        public CellVM[][] frontSide {  get; set; }
        double speed;
        public double Speed
        {
            get {
                
             return speed; }
            set
            {
                speed = value;
                OnPropertyChanged("StrSpeed");
            }
        }
        public string StrSpeed
        {
            get
            {
                return string.Format("Cкорость вращения: {0:f2}", speed);
            }
        }
        public CellVM[][] backSide { get; set; }
        public CellVM[][] leftSide { get; set; }
        public CellVM[][] rightSide { get; set; }
        public CellVM[][] bottomSide { get; set; }
        public CellVM[][] topSide {  get; set; }
        
        public Btn[] commands { get; set; } = new Btn[12] {new Btn("F"),new Btn("B"),new Btn( "U"),
            new Btn("D"), new Btn("L"),new Btn("R"),
            new Btn( "F'"),new Btn( "B'"),new Btn("U'"),
            new Btn ("D'"),new Btn( "L'"),new Btn( "R'") };
        public DispatcherTimer timer = new DispatcherTimer();
        Point3D cameraPosition {  get; set; }
        public Vector3D LookDirection { get; set; }
        
        public Point3D CameraPosition
        {
            get { return cameraPosition; }
            set { cameraPosition = value; OnPropertyChanged("CameraPosition"); }
        }

        int fps = 30;

        public bool DownKey, UpKey, LeftKey, RightKey;
        public CameraPosition rotateVector { get; set; } = new CameraPosition();
        public string Xst { get { return string.Format("x: {0:f2}",rotateVector.X); } }
        public string Yst { get { return string.Format( "y: {0:f2}", rotateVector.Y); } }
        public string Zst { get {
                
                return string.Format("z: {0:f2} ", rotateVector.Z); } }

        public CubeModelVM()
        {
            
            DownKey = UpKey = LeftKey = RightKey = false;


            frontSide = initCubeSide("green");
            leftSide = initCubeSide("purple");
            rightSide = initCubeSide("orange");
            backSide = initCubeSide("blue");
            topSide = initCubeSide("red");
            bottomSide = initCubeSide("white");

            speed = 0.25;
           
            CameraPosition = new Point3D(rotateVector.X, rotateVector.Y, rotateVector.Z);
            LookDirection = new Vector3D(rotateVector.LookDirectionVectorX, rotateVector.LookDirectionVectorY, rotateVector.LookDirectionVectorZ);
            timer.Interval = TimeSpan.FromMilliseconds(1000 / fps);
            timer.Tick += RotateTick;
            timer.Start();
        }
        private CellVM[][] initCubeSide(string color)
        {
            CellVM[][] side = new CellVM[3][];

            for (int i = 0; i < 3; i++)
            {
                side[i] = new CellVM[3];
                for (int j = 0; j < 3; j++)
                {
                    side[i][j] = new CellVM();
                    side[i][j].Color = color;
                }
            }
            
            return side;
        }
        public void GenerateSides()
        {
            for (int i = 0;i < 3;i++)
            {
                for(int j = 0;j < 3; j++)
                {
                    frontSide[i][j].Color = "green";
                    leftSide[i][j].Color = "purple";
                    rightSide[i][j].Color = "orange";
                    bottomSide[i][j].Color = "white";
                    topSide[i][j].Color = "red";
                    backSide[i][j].Color = "blue";
                }
            }
        }
        public void cubeMotion(string cmd)

        {
            string container = "";
            if (cmd == "L")
            {

                for (int i = 0; i < 3; i++)
                {
                    container = frontSide[0][i].Color;
                    frontSide[0][i].PureColor(bottomSide[0][i].Color);
                    bottomSide[0][i].PureColor(backSide[0][i].Color);
                    backSide[0][i].PureColor(topSide[0][i].Color);
                    topSide[0][i].PureColor(container);
                }
            }
            if (cmd == "L'")
            {
                for (int i = 0; i < 3; i++)
                {
                    container = frontSide[0][i].Color;
                    frontSide[0][i].PureColor(topSide[0][i].Color);
                    topSide[0][i].PureColor(backSide[0][i].Color);
                    backSide[0][i].PureColor(bottomSide[0][i].Color);
                    bottomSide[0][i].PureColor(container);
                }
            }
            if (cmd == "R")
            {

                for (int i = 0; i < 3; i++)
                {
                    container = frontSide[2][i].Color;
                    frontSide[2][i].PureColor(bottomSide[2][i].Color);
                    bottomSide[2][i].PureColor(backSide[2][i].Color);
                    backSide[2][i].PureColor(topSide[2][i].Color);
                    topSide[2][i].PureColor(container);
                }
            }
            if (cmd == "R'")
            {
                for (int i = 0; i < 3; i++)
                {
                    container = frontSide[2][i].Color;
                    frontSide[2][i].PureColor(topSide[2][i].Color);
                    topSide[2][i].PureColor(backSide[2][i].Color);
                    backSide[2][i].PureColor(bottomSide[2][i].Color);
                    bottomSide[2][i].PureColor(container);
                }
            }
            
            if (cmd == "D'")
            {
                for (int i = 0; i < 3; i++)
                {
                    container = frontSide[i][0].Color;
                    frontSide[i][0].PureColor(leftSide[i][0].Color);
                    leftSide[i][0].PureColor(backSide[i][0].Color);
                    backSide[i][0].PureColor(rightSide[i][0].Color);
                    rightSide[i][0].PureColor(container);

                }
            }
            if (cmd == "D")
            {
                for (int i = 0; i < 3; i++)
                {
                    container = frontSide[i][0].Color;
                    frontSide[i][0].PureColor(rightSide[i][0].Color);
                    rightSide[i][0].PureColor(backSide[i][0].Color);
                    backSide[i][0].PureColor(leftSide[i][0].Color);
                    leftSide[i][0].PureColor(container);
                    
                }
            }
            if (cmd == "U'")
            {
                for (int i = 0; i < 3; i++)
                {
                    container = frontSide[i][2].Color;
                    frontSide[i][2].PureColor(leftSide[i][2].Color);
                    leftSide[i][2].PureColor(backSide[i][2].Color);
                    backSide[i][2].PureColor(rightSide[i][2].Color);
                    rightSide[i][2].PureColor(container);

                }
            }
            if (cmd == "U")
            {
                for (int i = 0; i < 3; i++)
                {
                    container = frontSide[i][2].Color;
                    frontSide[i][2].PureColor(rightSide[i][2].Color);
                    rightSide[i][2].PureColor(backSide[i][2].Color);
                    backSide[i][2].PureColor(leftSide[i][2].Color);
                    leftSide[i][2].PureColor(container);
                }
            }
            if (cmd == "B")
            {
                for(int i = 0;i < 3;i++)
                {
                    container = leftSide[0][i].Color;
                    leftSide[0][i].PureColor(bottomSide[i][0].Color);
                    bottomSide[i][0].PureColor(rightSide[2][i].Color);
                    rightSide[2][i].PureColor(topSide[i][2].Color);
                    topSide[i][2].PureColor(container);
                }
            }
            if (cmd == "B'")
            {
                for (int i = 0; i < 3; i++)
                {
                    container = leftSide[0][i].Color;
                    leftSide[0][i].PureColor(topSide[i][2].Color);
                    topSide[i][2].PureColor(rightSide[2][i].Color);
                    rightSide[2][i].PureColor(bottomSide[i][0].Color);
                    bottomSide[i][0].PureColor(container);
                }
            }
            if (cmd == "F")
            {
                for (int i = 0; i < 3; i++)
                {
                    container = leftSide[2][i].Color;
                    leftSide[2][i].PureColor(bottomSide[i][2].Color);
                    bottomSide[i][2].PureColor(rightSide[0][i].Color);
                    rightSide[0][i].PureColor(topSide[i][0].Color);
                    topSide[i][0].PureColor(container);
                }
            }
            if (cmd == "F'")
            {
                for (int i = 0; i < 3; i++)
                {
                    container = leftSide[2][i].Color;
                    leftSide[2][i].PureColor(topSide[i][0].Color);
                    topSide[i][0].PureColor(rightSide[0][i].Color);
                    rightSide[0][i].PureColor(bottomSide[i][2].Color);
                    bottomSide[i][2].PureColor(container);
                }
            }
        
    }

        private void RotateTick(object sender, EventArgs e)
        {
            
            if (RightKey || LeftKey || DownKey ||  UpKey)
            {
                if (RightKey)
                {
                    
                    rotateVector.X = -speed;
                }
                if (LeftKey)
                {
                    
                    rotateVector.X = speed;
                    
                }
                if (DownKey)
                {
                    
                    rotateVector.Y = speed;
                    
                }
                if (UpKey)
                {
                   
                    rotateVector.Y = -speed;
                }
                
                CameraPosition = new Point3D(rotateVector.X, rotateVector.Y, rotateVector.Z);
                
                LookDirection = new Vector3D(rotateVector.LookDirectionVectorX, rotateVector.LookDirectionVectorY, rotateVector.LookDirectionVectorZ);
                OnPropertyChanged("LookDirection");
            }
            OnPropertyChanged("Zst");
            OnPropertyChanged("Xst");
            OnPropertyChanged("Yst");
            
        }
        

        public event PropertyChangedEventHandler PropertyChanged;
        public void OnPropertyChanged([CallerMemberName] string prop = "")
        {
            if (PropertyChanged != null)
                PropertyChanged(this, new PropertyChangedEventArgs(prop));
        }
    }
}
