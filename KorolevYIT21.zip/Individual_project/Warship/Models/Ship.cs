﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Individual_project.Warship.Models
{
    internal class Ship : AbsShip
    {
        public new int Deck { get; set; }
        public new int[][] Dots { get; set; }
       
        public Ship(int deck) {
           Deck = deck;

            Dots = new int[deck][];
            
           for (int i = 0; i < Dots.Length; i++)
            {
                Dots[i] = new int[2];
                Dots[i][0] = 2;
                Dots[i][1] = 2;
            }
           
        }
        
        public override int CompareTo(IShip other)
        {
            return Deck.CompareTo(other.Deck);
        }
        public override bool ContainDots(int k, int t)
        {
            for(int i = 0; i < Dots.Length; i++)
            {
                if (Dots[i][0] == k && Dots[i][1] == t)
                {
                    return true;
                }
            }
            
            return false;
        }
    }
}
