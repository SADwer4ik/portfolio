﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Individual_project.Warship.Models
{
    internal interface IShip
    {
        int Deck { get; set; }
        int[][] Dots { get; set; }
        
        
    }
}
