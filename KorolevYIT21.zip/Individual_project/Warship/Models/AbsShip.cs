﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Individual_project.Warship.Models
{
    internal abstract class AbsShip : IShip, IComparable<IShip>
    {
        public int Deck { get; set; }
        public int[][] Dots { get; set; }
        

        public abstract int CompareTo(IShip other);
        public abstract bool ContainDots(int k, int t);
    }
}
