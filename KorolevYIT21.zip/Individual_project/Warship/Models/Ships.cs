﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Navigation;

namespace Individual_project.Warship.Models
{
    internal class Ships : IList<Ship>
    {
        private Ship[] _ships;
        private int count = 0;
        
        public int Count
        {
            get { return count + 1; }
        }
        public Ships() {
            _ships = new Ship[10];
            count = 0;
        }

        public Ship this[int index]
        {
            get
            {
                if (index < 0 || index >= Count)
                {
                    throw new ArgumentOutOfRangeException
                    ("index", index, "Indexer out of range");
                }
                return _ships[index];
            }
            set
            {
                if (index < 0 || index >= count)
                {
                    throw new ArgumentOutOfRangeException("index", index, "Indexer out of range");
                }
                else
                {
                    _ships[index] = value;
                }
            }
        }
        

       

        public bool IsReadOnly
        {
            get { return false; }
        }

        public void Add(Ship item)
        {
            if (!Contains(item))
            {
                if (count != _ships.Length)
                {
                    _ships[count] = item;
                    count++;
                }
                
            }
        }
        public Ship ShipFromDot(int a, int b)
        {
            foreach(Ship ship in _ships)
            {
                if (ship == null) continue;
                if (ship.ContainDots(a, b))
                {
                    return ship;
                }
            }
            return null;
        }
        
        public void Clear()
        {
            count = 0;
        }

        public bool Contains(Ship item)
        {
            if (_ships == null) {  return false; }
            foreach(Ship ship in _ships)
            {
                if (ship != null)
                {
                    if (ship.Equals(item)) return true;
                }
                
            }
            return false;
        }

        public void CopyTo(Ship[] array, int arrayIndex)
        {
            throw new NotImplementedException();
        }

        public IEnumerator<Ship> GetEnumerator() => new ShipEnumerator(_ships);

        public int IndexOf(Ship item)
        {
            for(int i = 0;i < count; i++)
            {
                if (_ships[i].Equals(item))
                {
                    return i;
                }
            }
            return -1;
        }

        public void Insert(int index, Ship item)
        {
            throw new NotImplementedException();
        }

        public bool Remove(Ship item)
        {
            throw new NotImplementedException();
        }

        public void RemoveAt(int index)
        {
            throw new NotImplementedException();
        }

        IEnumerator IEnumerable.GetEnumerator() => new ShipEnumerator(_ships);
    }
    class ShipEnumerator : IEnumerator<Ship>
    {
        Ship[] _ships;
        int index = -1;
        public ShipEnumerator(Ship[] ships) => this._ships = ships;
        public Ship Current
        {
            get
            {
                if (index == -1 || index >= _ships.Length)
                {
                    throw new ArgumentException();
                }
                return _ships[index];
            }
        }

        Ship IEnumerator<Ship>.Current => Current;

        object IEnumerator.Current => Current;

        public void Dispose() { }

        public bool MoveNext()
        {
            if (index < _ships.Length - 1)
            {
                index++;
                return true;
            }
            else
                return false;
        }

        public void Reset() => index = -1;
    }
}
