﻿
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace Individual_project.Warship.MV
{
    internal class CellVM : INotifyPropertyChanged
    {
        public Colors hue { get; set; }
       private int deck {  get; set; }
        public int Deck {
            get
            {
                return deck;
            }
            set {
                
                    deck = value; OnPropertyChanged("Deck");
                    
            }
        }
        public string Color
        {
            get
            {
                if (hue == Colors.Blue)
                {
                    return "#0000ff";
                }
                else if (hue == Colors.Green)
                {
                    return "#b7ff2b";
                }
                else if (hue == Colors.Grey)
                {
                    return "#c8a165";
                }
                else if (hue == Colors.Yellow)
                {
                    return "#ecff00";
                }
                else if (hue == Colors.White)
                {
                    return "#ffdab9";
                }
                else if (hue == Colors.Purple)
                {
                    return "#a5209b";
                }
                else
                {
                    return "#7F1425";
                }
            }
            set
            {
                if (!cellState)
                {
                    if (value == "")
                    {
                        switch (deck)
                        {
                            case 0:
                                hue = Colors.Grey; break;
                            case 1:
                                hue = Colors.Yellow; break;
                            case 2:
                                hue = Colors.Green; break;
                            case 3:
                                hue = Colors.Blue; break;
                            case 4:
                                hue = Colors.Purple; break;
                        }
                    }
                    else
                    {
                        hue = Colors.Red;
                    }
                    

                    OnPropertyChanged("Color");
                }
            }
            
        }
        
    
        public bool cellState { get; set; }
        public CellVM()
        {
            Deck = 0;
            hue = Colors.White;
            cellState = false;
        }
        public event PropertyChangedEventHandler PropertyChanged;
        public void OnPropertyChanged([CallerMemberName] string prop = "")
        {
            if (PropertyChanged != null)
                PropertyChanged(this, new PropertyChangedEventArgs(prop));
        }
    }
    enum Colors : short
    {
        White = 0,
        Grey = 5,
        Green = 1,
        Yellow = 2,
        Blue = 3,
        Purple = 4,
        Red = 6,
    }
}
