﻿using Individual_project.Warship.MV;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Individual_project.Battleship.MV
{
    internal class Battlefield
    {
        public CellVM[,] gamefield;
    }
}
