﻿using Individual_project.Battleship.View;
using Individual_project.Warship.MV;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Individual_project.Warship
{
    /// <summary>
    /// Interaction logic for Battleship.xaml
    /// </summary>
    public partial class Battleship : Window
    {
        BattleField battleField = new BattleField();
        public Battleship()
        {
            DataContext = battleField;
            InitializeComponent();
        }

        private void Hit_Click(object sender, MouseButtonEventArgs e)
        {
            bool IsEnd;
            var brd = sender as Border;
            CellVM cell = brd.DataContext as CellVM;
            if (!cell.cellState)
            {
                
                cell.Color = "";
                cell.cellState = true;
                if (cell.Deck != 0)
                {
                    battleField.playerScore = "";
                }
                IsEnd = battleField.BotMove();
                if (IsEnd)
                {
                    this.Close();
                }
            }
        }
    }
}
