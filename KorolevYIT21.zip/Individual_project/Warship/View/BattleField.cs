﻿using Individual_project.Warship.Models;
using Individual_project.Warship.MV;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Media.Animation;

namespace Individual_project.Battleship.View
{
    internal class BattleField : INotifyPropertyChanged
    {
        private Ships PlayerShips { get; set; }
        private Ships BotShips { get; set; }
        public CellVM[][] playerField { get; set; }
        public CellVM[][] botField { get; set; }
        private Random rnd = new Random();
        private int botScores;
        private int playerScores;

        public event PropertyChangedEventHandler PropertyChanged;
        public void OnPropertyChanged([CallerMemberName] string prop = "")
        {
            if (PropertyChanged != null)
                PropertyChanged(this, new PropertyChangedEventArgs(prop));
        }

        public string playerScore
        {
            get
            {
                return "Ваши очки: " + playerScores.ToString();
            }
            set
            {
                playerScores++;
                OnPropertyChanged("PlayerScore");
            }
        }
        public string botScore
        {
            get
            {
                return "Очки бота: " + botScores.ToString();
            }
            set
            {
                botScores++;
                
                OnPropertyChanged("botScore");
            }
        }

        public BattleField()
        {
            playerField = GenerateField();
            botField = GenerateField();
            PlayerShips = new Ships();
            BotShips = new Ships();
            botScores = playerScores = 0;
            rerenderField();
        }
        public void rerenderField()
        {
            ArrShips(true);
            ArrShips(false);
            for (int i = 0; i < 10; i++)
            {
                for (int j = 0; j < 10; j++)
                {
                    Ship ship = PlayerShips.ShipFromDot(i, j);
                    if (ship != null)
                    {
                        playerField[i][j].Deck = ship.Deck;
                        playerField[i][j].Color = "";
                    }
                    ship = BotShips.ShipFromDot(i, j);
                    if (ship != null)
                    {
                        botField[i][j].Deck = ship.Deck;
                    }
                }
            }
        }
        public CellVM[][] GenerateField()
        {
            CellVM[][] field = new CellVM[10][];
            for (int i = 0; i < 10; i++)
            {
                field[i] = new CellVM[10];
                for (int j = 0; j < 10; j++)
                {
                    field[i][j] = new CellVM();
                }
            }
            return field;
        }

        public bool BotMove()
        {
            
            while (true)
            {
                int i = rnd.Next(10);
                int j = rnd.Next(10);
                if (!playerField[i][j].cellState)
                {
                    playerField[i][j].Color = "1";
                    playerField[i][j].cellState = true;
                    if (playerField[i][j].Deck > 0) {
                        botScore = "";
                    }

                    break;
                }
            }
            if (botScores == 20 && playerScores == 20)
            {
                MessageBox.Show("Ничья");
                return true;
            }
            else if (botScores == 20)
            {
                MessageBox.Show("Бот победил");
                return true;
            }
            else if(playerScores == 20)
            {

                MessageBox.Show("Вы победили");
                return true;
            }
            return false;
        }
        private void ArrShips(bool isPlayer)
        {
            if (isPlayer)
            {
                PlayerShips.Add(ChooseArr(4, isPlayer));
                for (int i = 0; i < 2; i++)
                {
                    PlayerShips.Add(ChooseArr(3, isPlayer));
                }
                for (int i = 0; i < 3; i++)
                {
                    PlayerShips.Add(ChooseArr(2, isPlayer));
                }
                for (int i = 0; i < 4; i++)
                {
                    PlayerShips.Add(ChooseArr(1, isPlayer));
                }
            }
            else
            {
                BotShips.Add(ChooseArr(4, isPlayer));
                for (int i = 0; i < 2; i++)
                {
                    BotShips.Add(ChooseArr(3, isPlayer));
                }
                for (int i = 0; i < 3; i++)
                {
                    BotShips.Add(ChooseArr(2, isPlayer));
                }
                for (int i = 0; i < 4; i++)
                {
                    BotShips.Add(ChooseArr(1, isPlayer));
                }
            }
        }

        private Ship ChooseArr(int deck, bool isPlayer)
        {
            
            
            int arr = rnd.Next(2);
            if (arr == 0)
            {
                return VerticalAl(deck, isPlayer);
            }
            else
            {
                return HorizontalAl(deck, isPlayer);
            }
            
           
        }

        private Ship VerticalAl(int deck, bool isPlayer)
        {
            Ship ship = new Ship(deck);
            

            while (true)
            {
                bool flag = true;
                int t = rnd.Next(10);
                int f = rnd.Next(10 - deck);
                for (int i = 0; i < deck + 2; i++)
                {
                    if (f + i - 1 >= 0 && f + i - 1 < 10)
                    {
                        for (int j = 0; j < 3; j++)
                        {
                            if (t + j - 1 >= 0 && t + j - 1 < 10)
                            {
                                if (isPlayer)
                                {
                                    if (PlayerShips.ShipFromDot(f + i - 1, t + j - 1) != null)
                                    {
                                        flag = false;
                                        break;
                                    }
                                }
                                else
                                {
                                    if (BotShips.ShipFromDot(f + i - 1, t + j - 1) != null)
                                    {
                                        flag = false;
                                        break;
                                    }
                                }
                            }
                        }
                    }
                }
                if (flag)
                {
                    for (int i = 0; i < deck; i++)
                    {
                        ship.Dots[i][0] = f + i;
                        ship.Dots[i][1] = t;
                    }
                    break;
                }
               
            }
            return ship;


        }

        private Ship HorizontalAl(int deck, bool isPlayer) {
            Ship ship = new Ship(deck);
            

            while (true)
            {
                bool flag = true;
                int t = rnd.Next(10);
                int f = rnd.Next(10 - deck);
                for (int i = 0; i < deck + 2; i++)
                {
                    if (f + i - 1 >= 0 && f + i - 1 < 10)
                    {
                        for (int j = 0; j < 3; j++)
                        {
                            if (t + j - 1 >= 0 && t + j -1 < 10)
                            {
                                if (isPlayer)
                                {
                                    if (PlayerShips.ShipFromDot(t + j - 1, f + i - 1) != null)
                                    {
                                        flag = false;
                                        break;
                                    }
                                }
                                else
                                {
                                    if (BotShips.ShipFromDot(t + j - 1, f + i - 1) != null)
                                    {
                                        flag = false;
                                        break;
                                    }
                                }
                            }
                        }
                    }
                }
                if (flag)
                {
                    for (int i = 0; i < deck; i++)
                    {
                        
                        ship.Dots[i][0] = t;
                        ship.Dots[i][1] = f + i;
                        
                    }
                    break;
                }

            }
            return ship;
        }

    }
}

