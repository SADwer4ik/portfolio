﻿using Individual_project.Dao;
using Individual_project.Entity;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Individual_project
{
    /// <summary>
    /// Interaction logic for EnterWindow.xaml
    /// </summary>
    public partial class EnterWindow : Window
    {
        DatabaseConnect dbconnect = new DatabaseConnect();
        public EnterWindow()
        {
            InitializeComponent();
        }


        public User RegisterUser
        {
            get {

                return new User(NickName.Text, Password.Text); }
        }

        public bool IsAutorizeClicked = false;

        private void Ok_Click(object sender, RoutedEventArgs e)
        {
            if (dbconnect.FindUser(new User(NickName.Text, Password.Text)))
            {
                this.DialogResult = true;
            }
            else
            {
                MessageBox.Show("Неверный логин или пароль");
            }
        }
        private void Autorization_Click(object sender, RoutedEventArgs e)
        {
            IsAutorizeClicked = true;
            this.DialogResult = false;
        }
        private void Keyboard_Click(object sender,  KeyEventArgs e)
        {
            if(e.Key  == Key.Enter)
            {
                this.DialogResult = true;
            }
        }
    }

}
