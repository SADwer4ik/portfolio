﻿using System;
using System.ComponentModel;
using System.Windows;


namespace Vectors
{
    public class CameraPosition
    {
        
        double x, y, z;
        public double radius;
        bool IsFront = true;
        public double LookDirectionVectorX, LookDirectionVectorY, LookDirectionVectorZ;

        

        public double X { get { return x; } set {
                double t;
                t = x;
                if (y*y == radius * radius)
                {
                    return;
                }
                if (IsFront)
                {
                    t += value;
                }
                else
                {
                    t -= value;
                }
                if ((t * t + y * y) > radius * radius)
                {
                    if (IsFront)
                    {
                        IsFront = false;
                    }
                    else
                    {
                        IsFront = true;
                    }
                }
                if (IsFront)
                {
                    x += value;
                }
                else
                {
                    x -= value;
                }
                
                calculateZ();

            } }
        public double Y { get { return y; } set {

                double t;
                if (x*x == radius*radius)
                {
                    return;
                }
                t = y;
                if (IsFront)
                {
                    t += value;
                }
                else
                {
                    t -= value;
                }
                if ((t * t + x * x) > radius * radius)
                {
                    if (IsFront)
                    {
                        IsFront = false;
                    }
                    else
                    {
                        IsFront = true;
                    }
                }
                
                if (IsFront)
                {
                    y += value;
                }
                else
                {
                    y -= value;
                }
               
                calculateZ();



            } }
        public double Z { get { return z; } set {  z = value; } }

        
        
        public CameraPosition()
        {
            x = 0;
            y = 0;
            z = 10;

            LookDirectionVectorX = -x;
            LookDirectionVectorY = -y;
            LookDirectionVectorZ = -z;
            radius = Math.Sqrt(z * z + y * y + x * x);
        }
        public void calculateZ()
        {
            
            if (IsFront)
            {
                z = Math.Sqrt(radius * radius - y * y - x * x);
            }
            else
            {
                z = -Math.Sqrt(radius * radius - y * y - x * x);
            }
            if (y * y == radius * radius)
            {
                z = 0.25;
            }
            
            
            LookDirectionVectorX = -x;
            LookDirectionVectorY = -y;
            LookDirectionVectorZ = -z;
        }
    }
}